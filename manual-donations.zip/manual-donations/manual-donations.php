<?php
/**
 * Plugin Name: Manual Donations
 * Description: Adds a manual donation page with offline payment instructions and confirmation form.
 * Version: 1.0
 * Author: Rollins
 */

add_shortcode('manual_donation_form', 'mdonation_render_form');

function mdonation_render_form() {
    ob_start();
    ?>
    <div style="max-width: 700px; margin: auto; font-family: Arial, sans-serif; line-height: 1.6;">
      <h2 style="text-align: center; color: #2c3e50;">Donate to Hearts United Foundation</h2>
      <p style="text-align: center; font-size: 18px;">Support our mission to uplift lives. You can donate using the options below.</p>

      <hr>

      <h3 style="color: #16a085;">📱 Mobile Money</h3>
      <ul>
        <li><strong>MTN:</strong> 0770 XXX XXX</li>
        <li><strong>Airtel:</strong> 0750 XXX XXX</li>
        <li><strong>Recipient Name:</strong> Hearts United Foundation</li>
      </ul>

      <h3 style="color: #2980b9;">🏦 Bank Transfer</h3>
      <ul>
        <li><strong>Bank Name:</strong> XYZ Bank Uganda</li>
        <li><strong>Account Name:</strong> Hearts United Foundation</li>
        <li><strong>Account Number:</strong> 123456789</li>
        <li><strong>SWIFT Code:</strong> XYZBUGKA</li>
      </ul>

      <p><em>After sending your donation, please fill the confirmation form below so we can verify and acknowledge your support.</em></p>

      <hr>

      <form method="post">
        <?php wp_nonce_field('manual_donation_nonce', 'manual_donation_nonce_field'); ?>
        <p><label>Full Name:<br><input type="text" name="md_name" required style="width:100%;padding:10px;"></label></p>
        <p><label>Email:<br><input type="email" name="md_email" required style="width:100%;padding:10px;"></label></p>
        <p><label>Phone:<br><input type="text" name="md_phone" required style="width:100%;padding:10px;"></label></p>
        <p><label>Amount (UGX):<br><input type="number" name="md_amount" required style="width:100%;padding:10px;"></label></p>
        <p>
          <label>Payment Method:<br>
            <select name="md_method" required style="width:100%;padding:10px;">
              <option value="">--Select--</option>
              <option value="MTN">MTN</option>
              <option value="Airtel">Airtel</option>
              <option value="Bank Transfer">Bank Transfer</option>
            </select>
          </label>
        </p>
        <p><label>Transaction Reference:<br><input type="text" name="md_ref" required style="width:100%;padding:10px;"></label></p>
        <p><label>Message (Optional):<br><textarea name="md_msg" style="width:100%;padding:10px;" rows="4"></textarea></label></p>
        <p><button type="submit" name="submit_manual_donation" style="padding:12px 20px;background:#27ae60;color:#fff;border:none;">Submit Confirmation</button></p>
      </form>
    </div>
    <?php
    return ob_get_clean();
}

add_action('init', function () {
    if (isset($_POST['submit_manual_donation']) && isset($_POST['manual_donation_nonce_field']) && wp_verify_nonce($_POST['manual_donation_nonce_field'], 'manual_donation_nonce')) {

        $body = "
New Manual Donation Received:

Name: {$_POST['md_name']}
Email: {$_POST['md_email']}
Phone: {$_POST['md_phone']}
Amount: UGX {$_POST['md_amount']}
Method: {$_POST['md_method']}
Reference: {$_POST['md_ref']}
Message: {$_POST['md_msg']}
";

        wp_mail(get_option('admin_email'), 'New Manual Donation', $body);
    }
});
// Register Manual Donation Widget
class Manual_Donation_Widget extends WP_Widget
{

    public function __construct()
    {
        parent::__construct(
            'manual_donation_widget',
            __('Manual Donation Form', 'manual-donation'),
            ['description' => __('Displays the manual donation form with instructions.', 'manual-donation')]
        );
    }

    public function widget($args, $instance)
    {
        echo $args['before_widget'];
        echo do_shortcode('[manual_donation_form]');
        echo $args['after_widget'];
    }

    public function form($instance)
    {
        echo '<p>No settings for this widget.</p>';
    }

    public function update($new_instance, $old_instance)
    {
        return $old_instance;
    }
}

// Register the widget
add_action('widgets_init', function () {
    register_widget('Manual_Donation_Widget');
});
